export  let data = {
    "0": {
      "0": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "1": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "2": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "3": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "4": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "5": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "6": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "7": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "8": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "9": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "10": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "11": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "12": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "13": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "14": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "15": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "16": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "17": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "18": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "19": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "20": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "21": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "22": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "23": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      }
    },
    "1": {
      "0": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "1": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "2": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "3": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "4": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "5": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "6": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "7": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "8": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "9": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "10": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "11": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "12": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "13": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "14": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "15": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "16": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "17": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "18": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "19": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "20": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "21": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "22": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "23": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      }
    },
    "2": {
      "0": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "1": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "2": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "3": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "4": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "5": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "6": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "7": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "8": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "9": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "10": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "11": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "12": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "13": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "14": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "15": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "16": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "17": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "18": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "19": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "20": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "21": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "22": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "23": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      }
    },
    "3": {
      "0": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "1": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "2": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "3": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "4": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "5": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "6": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "7": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "8": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "9": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "10": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "11": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "12": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "13": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "14": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "15": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "16": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "17": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "18": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "19": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "20": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "21": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "22": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "23": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      }
    },
    "4": {
      "0": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "1": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "2": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "3": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "4": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "5": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "6": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "7": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "8": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "9": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "10": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "11": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "12": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "13": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "14": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "15": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "16": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "17": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "18": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "19": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "20": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "21": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "22": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "23": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      }
    },
    "5": {
      "0": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "1": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "2": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "3": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "4": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "5": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "6": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "7": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "8": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "9": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "10": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "11": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "12": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "13": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "14": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "15": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "16": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "17": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "18": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "19": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "20": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "21": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "22": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "23": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      }
    },
    "6": {
      "0": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "1": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "2": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "3": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "4": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "5": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "6": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "7": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "8": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "9": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "10": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "11": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "12": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "13": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "14": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "15": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "16": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "17": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "18": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "19": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "20": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "21": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "22": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      },
      "23": {
        "1": null,
        "2": null,
        "3": null,
        "4": null,
        "hourAvg": null
      }
    }
  }