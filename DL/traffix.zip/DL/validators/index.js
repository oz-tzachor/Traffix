const validateNewUser = require("../validators/userSchemaJoi");
module.exports = { validateNewUser };
