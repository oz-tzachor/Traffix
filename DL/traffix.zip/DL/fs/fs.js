const fs = require("fs");
let saveNewChartImage = () => {};
let deleteImage = () => {};
module.exports = { saveNewChartImage, deleteImage };
